package org.example;

import org.junit.jupiter.api.Test;

import java.io.File;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class FileManagerTest {
    // I don't know how to do test cases for methods that use textIO... I shall ask you in class!

}